package com.expect.admin.web;

import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.IAttributeNameProcessorMatcher;
import org.thymeleaf.processor.ProcessorResult;
import org.thymeleaf.processor.attr.AbstractAttrProcessor;

public class TextAttrProcessor extends AbstractAttrProcessor  {

	protected TextAttrProcessor(IAttributeNameProcessorMatcher matcher) {
		super(matcher);
	}

	@Override
	protected ProcessorResult processAttribute(Arguments arg0, Element arg1, String arg2) {
		return null;
	}

	@Override
	public int getPrecedence() {
		return 0;
	}

}
