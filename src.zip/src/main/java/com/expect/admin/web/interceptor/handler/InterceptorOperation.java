package com.expect.admin.web.interceptor.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 拦截器中，具体操作的接口
 */
public interface InterceptorOperation {

	public boolean operation(HttpServletRequest request, HttpServletResponse response, Object handler);

}
