package com.expect.admin.web;

import java.util.HashSet;
import java.util.Set;

import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.processor.IProcessor;

public class FormDialect extends AbstractDialect {

	@Override
	public String getPrefix() {
		return "form";
	}

	@Override
	public Set<IProcessor> getProcessors() {
		final Set<IProcessor> processors = new HashSet<>();
		return processors;
	}
}
