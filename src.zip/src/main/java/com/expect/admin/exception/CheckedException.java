package com.expect.admin.exception;

/**
 * @author CYX
 * 说明:系统中的所有checked exception的父类
 */
public class CheckedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1456829047683935632L;
	public CheckedException(){
		super();
	}
	public CheckedException(String msg){
		super(msg);
	}
	public CheckedException(String msg, Throwable e){
		super(msg, e);
	}

}
