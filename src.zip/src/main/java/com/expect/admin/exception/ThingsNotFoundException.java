package com.expect.admin.exception;

/**
 * @author zcz
 * 说明:系统中用于查找失败的exception
 */
public class ThingsNotFoundException extends CheckedException {

	private static final long serialVersionUID = -2798276323827761396L;
	public ThingsNotFoundException(){
		super();
	}
	public ThingsNotFoundException(String msg){
		super(msg);
	}
	public ThingsNotFoundException(String msg, Throwable e){
		super(msg, e);	
	}
}
