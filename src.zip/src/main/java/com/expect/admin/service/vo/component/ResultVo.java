package com.expect.admin.service.vo.component;

public class ResultVo extends BaseVo {

	protected String message;
	protected boolean result;
	protected Object obj;
	private String code;

	public ResultVo() {

	}

	public ResultVo(boolean result) {
		this.result = result;
	}

	public ResultVo(boolean result, String message) {
		this.message = message;
		this.result = result;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
