/*  1:   */package com.expect.admin.service.vo;
/*  2:   */
/*  3:   */import java.util.Comparator;
/*  4:   */
/*  7:   */public class YdsjCompare
/*  8:   */  implements Comparator<DocumentVo>
/*  9:   */{
/* 10:   */  public int compare(DocumentVo a, DocumentVo b)
/* 11:   */  {
/* 12:12 */    if (b.getYdsj() != null) {
/* 13:13 */      return b.getYdsj().compareTo(a.getYdsj());
/* 14:   */    }
/* 15:15 */    return -1;
/* 16:   */  }
/* 17:   */}


/* Location:           Z:\spring-boot-admin-0.0.1-SNAPSHOT.jar
 * Qualified Name:     BOOT-INF.classes.com.expect.admin.service.vo.YdsjCompare
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */