package com.expect.admin.service.vo;

import org.springframework.beans.BeanUtils;

import com.expect.admin.data.dataobject.RoleJdgxbGxb;


public class RoleJdgxbGxbVo {
	private String id;
	private String roleId;
	private String jdId;
	
	public RoleJdgxbGxbVo() {
	}
	
	public RoleJdgxbGxbVo(RoleJdgxbGxb gxb) {
		BeanUtils.copyProperties(gxb, this);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getJdId() {
		return jdId;
	}

	public void setJdId(String jdId) {
		this.jdId = jdId;
	}
	
	
	
}
