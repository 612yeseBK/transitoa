package com.expect.admin.service.vo;


public class DmbVo {

	private String lbbh;//类别编号
	private String dmbh;//代码编号
	private String dmms;//代码描述，代码的值
	private String bz;//备注
	
	public String getLbbh() {
		return lbbh;
	}
	public void setLbbh(String lbbh) {
		this.lbbh = lbbh;
	}
	public String getDmbh() {
		return dmbh;
	}
	public void setDmbh(String dmbh) {
		this.dmbh = dmbh;
	}
	public String getDmms() {
		return dmms;
	}
	public void setDmms(String dmms) {
		this.dmms = dmms;
	}
	public String getBz() {
		return bz;
	}
	public void setBz(String bz) {
		this.bz = bz;
	}
	
	
}
