package com.expect.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expect.admin.data.dao.DraftSwRepository;
import com.expect.admin.data.dao.DraftSwUserLcrzbGxbRepository;

@Service
public class DraftSwUserLcrzbGxbService {

	@Autowired
	private DraftSwUserLcrzbGxbRepository draftSwUserLcrzbGxbRepository;
	@Autowired
	private DraftSwRepository draftSwRepository;
	
	
}
