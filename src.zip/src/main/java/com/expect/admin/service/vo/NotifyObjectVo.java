package com.expect.admin.service.vo;

import com.expect.admin.data.dataobject.NotifyObject;

/**
 * Created by qifeng on 17/5/11.
 */
public class NotifyObjectVo {
    private String id;
    private String tzdxfl;
    private String tzdx;//用户全称
    private String userName;//用户名

    public NotifyObjectVo(){

    }
    public NotifyObjectVo(NotifyObject notifyObject) {
        this.id = notifyObject.getId();
        this.tzdxfl = notifyObject.getTzdxfl();
        this.tzdx = notifyObject.getTzdx();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTzdxfl() {
        return tzdxfl;
    }

    public void setTzdxfl(String tzdxfl) {
        this.tzdxfl = tzdxfl;
    }

    public String getTzdx() {
        return tzdx;
    }

    public void setTzdx(String tzdx) {
        this.tzdx = tzdx;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
