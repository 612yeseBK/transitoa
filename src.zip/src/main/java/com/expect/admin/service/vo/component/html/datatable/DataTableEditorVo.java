package com.expect.admin.service.vo.component.html.datatable;

import com.expect.admin.service.vo.component.ResultVo;

public class DataTableEditorVo extends ResultVo {

	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
