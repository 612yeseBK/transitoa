package com.expect.admin.service.vo;

import java.util.Date;


public class LogVo {
	
	/**
	 * 操作类型 更新
	 */
	public static final String CZLX_UPDATE = "update";
	/**
	 * 操作类型 删除
	 */
	public static final String CZLX_DELETE = "delete";
	/**
	 * 操作类型 新增
	 */
	public static final String CZLX_ADD = "add";
	
	
	private String id;
	private Date czsj;//操作时间
	private String yhmc;//用户名称
	private String czlx;//操作类型
	private String ywlx;//业务类型
	private String cznrid;//操作内容id
	private String yhip;//用户IP
	private String dwid;//用户单位id
	private String czjg;//操作结果
	private String rzxq;//日志详情
	private String cznrmc;//操作内容名称
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getCzsj() {
		return czsj;
	}
	public void setCzsj(Date czsj) {
		this.czsj = czsj;
	}
	public String getYhmc() {
		return yhmc;
	}
	public void setYhmc(String yhmc) {
		this.yhmc = yhmc;
	}
	public String getCzlx() {
		return czlx;
	}
	public void setCzlx(String czlx) {
		this.czlx = czlx;
	}
	public String getYwlx() {
		return ywlx;
	}
	public void setYwlx(String ywlx) {
		this.ywlx = ywlx;
	}
	public String getCznrid() {
		return cznrid;
	}
	public void setCznrid(String cznrid) {
		this.cznrid = cznrid;
	}
	public String getYhip() {
		return yhip;
	}
	public void setYhip(String yhip) {
		this.yhip = yhip;
	}
	public String getDwid() {
		return dwid;
	}
	public void setDwid(String dwid) {
		this.dwid = dwid;
	}
	public String getCzjg() {
		return czjg;
	}
	public void setCzjg(String czjg) {
		this.czjg = czjg;
	}
	public String getRzxq() {
		return rzxq;
	}
	public void setRzxq(String rzxq) {
		this.rzxq = rzxq;
	}
	public String getCznrmc() {
		return cznrmc;
	}
	public void setCznrmc(String cznrmc) {
		this.cznrmc = cznrmc;
	}
	
	
}
