package com.expect.admin.service.vo.component;

import com.expect.admin.utils.JacksonJsonUtil;

public class BaseVo {

	@Override
	public String toString() {
		String result = JacksonJsonUtil.getInstance().write(this);
		return result;
	}

}
