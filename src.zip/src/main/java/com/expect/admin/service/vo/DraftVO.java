package com.expect.admin.service.vo;

import java.util.Date;

public class DraftVO {
	private String id;
	private String ngr;//拟稿人
	private String ztc;//主题词
	private int mj;//密级
	private String sfmhwzfb;//是否门户网站发布（Y： 发布  N:不发布）
	private String zs;//主送
	private String cb;//抄报
	private String cs;//抄送
	private String bmhgyj;//部门核稿意见
	private String bmfzrhgyj;//部门负责人核稿意见
	private String hqyj;//会签意见
	private String hgyj;//核稿意见
	private Date yfrq;//印发日期
	private int fs;//份数
	private String dyr;//打印人
	private String jdr;//校对人
	private String bh;//编号
	private String bz;//备注
	private String sfjtng;//是否集团拟稿
	private String ngshzt;//拟稿审核状态
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNgr() {
		return ngr;
	}
	public void setNgr(String ngr) {
		this.ngr = ngr;
	}
	public String getZtc() {
		return ztc;
	}
	public void setZtc(String ztc) {
		this.ztc = ztc;
	}
	public int getMj() {
		return mj;
	}
	public void setMj(int mj) {
		this.mj = mj;
	}
	public String getSfmhwzfb() {
		return sfmhwzfb;
	}
	public void setSfmhwzfb(String sfmhwzfb) {
		this.sfmhwzfb = sfmhwzfb;
	}
	public String getZs() {
		return zs;
	}
	public void setZs(String zs) {
		this.zs = zs;
	}
	public String getCb() {
		return cb;
	}
	public void setCb(String cb) {
		this.cb = cb;
	}
	public String getCs() {
		return cs;
	}
	public void setCs(String cs) {
		this.cs = cs;
	}
	public String getBmhgyj() {
		return bmhgyj;
	}
	public void setBmhgyj(String bmhgyj) {
		this.bmhgyj = bmhgyj;
	}
	public String getBmfzrhgyj() {
		return bmfzrhgyj;
	}
	public void setBmfzrhgyj(String bmfzrhgyj) {
		this.bmfzrhgyj = bmfzrhgyj;
	}
	public String getHqyj() {
		return hqyj;
	}
	public void setHqyj(String hqyj) {
		this.hqyj = hqyj;
	}
	public String getHgyj() {
		return hgyj;
	}
	public void setHgyj(String hgyj) {
		this.hgyj = hgyj;
	}
	public Date getYfrq() {
		return yfrq;
	}
	public void setYfrq(Date yfrq) {
		this.yfrq = yfrq;
	}
	public int getFs() {
		return fs;
	}
	public void setFs(int fs) {
		this.fs = fs;
	}
	public String getDyr() {
		return dyr;
	}
	public void setDyr(String dyr) {
		this.dyr = dyr;
	}
	public String getJdr() {
		return jdr;
	}
	public void setJdr(String jdr) {
		this.jdr = jdr;
	}
	public String getBh() {
		return bh;
	}
	public void setBh(String bh) {
		this.bh = bh;
	}
	public String getBz() {
		return bz;
	}
	public void setBz(String bz) {
		this.bz = bz;
	}
	public String getSfjtng() {
		return sfjtng;
	}
	public void setSfjtng(String sfjtng) {
		this.sfjtng = sfjtng;
	}
	public String getNgshzt() {
		return ngshzt;
	}
	public void setNgshzt(String ngshzt) {
		this.ngshzt = ngshzt;
	}
	
	
}
