package com.expect.admin.service.vo.component.html.memo;

import com.expect.admin.service.vo.component.ResultVo;

/**
 * 备忘录Item vo
 */
public class MemoItemVo extends ResultVo {

	private String id;
	private String time;
	private String desc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}