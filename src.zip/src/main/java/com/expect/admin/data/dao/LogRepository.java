package com.expect.admin.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.expect.admin.data.dataobject.LogSys;

public interface LogRepository extends JpaRepository<LogSys, String>{

}
