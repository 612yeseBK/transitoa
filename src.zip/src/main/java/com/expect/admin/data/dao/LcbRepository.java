package com.expect.admin.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.expect.admin.data.dataobject.Lcb;

public interface LcbRepository extends JpaRepository<Lcb, String> {

}
