package com.expect.admin.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.expect.admin.data.dataobject.Wjxgry;

public interface WjxgryRepository extends JpaRepository<Wjxgry, String> {

}
