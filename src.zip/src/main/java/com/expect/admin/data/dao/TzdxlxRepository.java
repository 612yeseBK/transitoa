package com.expect.admin.data.dao;

import com.expect.admin.data.dataobject.Tzdxlx;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by qifeng on 17/5/4.
 */
public interface TzdxlxRepository extends JpaRepository<Tzdxlx,String> {
}
