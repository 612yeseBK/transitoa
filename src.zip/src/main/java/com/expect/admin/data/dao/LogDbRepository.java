package com.expect.admin.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.expect.admin.data.dataobject.LogDb;

/**
 * 日志JPA
 */
public interface LogDbRepository extends JpaRepository<LogDb, String> {

}
