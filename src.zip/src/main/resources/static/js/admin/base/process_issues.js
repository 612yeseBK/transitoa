// var cList = JSON.parse()
// $('#cyrRecordList').val();
// var title='';
// var text='已传阅(';
// for(var i=0;i<cList.length;i++) {
//     title += ('加注意见:'+(cList[i].message==''?'无':cList[i].message)+'&#10;传阅时间:'+ cList[i].clsj);
//     text += (i===0? cList[i].userName:','+cList[i].userName);
// }
// $('#cyrRecord').attr('title',title);
// $('#cyrRecord').attr('text',text+')');



$(".process").click(function (e) {
    if(e.target.title) {
        swal({
            title: "处理情况",
            text: e.target.title,
            html: true
        });
    }
})



